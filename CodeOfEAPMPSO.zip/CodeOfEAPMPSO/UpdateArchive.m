function Archive = UpdateArchive(Archive,N)
% Update the archive
    %% Find the non-dominated solutions
    Archive = Archive(NDSort(Archive.objs,1)==1);
    
    %% Truncate the archive according to the crowding distances
    while length(Archive) > N
        [~,rank] = sort(CrowdingDistance(Archive.objs));
        Archive(rank(randi(ceil(length(rank)*0.1)))) = [];
    end
    [~,rank] = sort(CrowdingDistance(Archive.objs),'descend');
    Archive  = Archive(rank);
end