classdef SOLUTION < handle
%SOLUTION - The class of a solution.
    properties(SetAccess = private)
        dec;        % Decision variables of the solution
        obj;        % Objective values of the solution
        con;        % Constraint violations of the solution
    end
    properties
        add;        % Additional properties of the solution
    end
    methods
        function obj = SOLUTION(PopDec,PopObj,PopCon,PopAdd)
        %SOLUTION - The constructor of SOLUTION.
            if nargin > 0
                obj(1,size(PopDec,1)) = SOLUTION;
                for i = 1 : length(obj)
                    obj(i).dec = PopDec(i,:);
                    obj(i).obj = PopObj(i,:);
                    obj(i).con = PopCon(i,:);
                end
                if nargin > 3
                    for i = 1 : length(obj)
                        obj(i).add = PopAdd(i,:);
                    end
                end
            end
        end
    end
    methods
        function obj = setDec(obj,inputDec)
            obj.dec = inputDec;
        end
        function obj = setObj(obj,inputObj)
            obj.obj = inputObj;
        end
        function value = decs(obj)
        %decs - Get the matrix of decision variables of multiple solutions.
            value = cat(1,obj.dec);
        end
        function value = objs(obj)
        %objs - Get the matrix of objective values of multiple solutions.
            value = cat(1,obj.obj);
        end
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of multiple solutions.
            value = cat(1,obj.con);
        end
        function value = adds(obj,Add)
        %adds - Get or set the matrix of additional properties of multiple solutions.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = Add(i,:);
                end
            end
            value = cat(1,obj.add);
        end
        function P = best(obj)
        %best - Get the best solutions among multiple solutions.
            Feasible = find(all(obj.cons<=0,2));
            if isempty(Feasible)
                Best = [];
            elseif length(obj(1).obj) > 1
                Best = NDSort(obj(Feasible).objs,1) == 1;
            else
                [~,Best] = min(obj(Feasible).objs);
            end
            P = obj(Feasible(Best));
        end
    end
end