function cosine_similarity = CosineSimilarity(vector1,vector2)
    % Check if the lengths of the input vectors are the same
    if length(vector1) ~= length(vector2)
        error('Input vectors must have the same length'); % Throw an error if the lengths are not equal
    end
    
    % Calculate the dot product of the two vectors
    dot_product = dot(vector1, vector2); % Compute the dot product using the built-in dot function
    
    % Calculate the norm (magnitude) of each vector
    norm_vector1 = norm(vector1); % Compute the Euclidean norm of vector1
    norm_vector2 = norm(vector2); % Compute the Euclidean norm of vector2
    
    % Calculate the cosine similarity between the two vectors
    cosine_similarity = dot_product / (norm_vector1 * norm_vector2); % Cosine similarity formula
end

