%% number represents the number of neighboring particles
function randNeighbors = RandNeighOfESE_SNR(Population, P, number)
    %% NEIGHBORS - Function to find random neighbors based on Euclidean distance
    %% Detailed description of the function's behavior

    Decs = Population.decs;  % Decision variables of the population
    Objs = Population.objs;  % Objective values of the population
    [N,D] = size(Objs);  % Number of particles and decision variables
    dists = zeros(N,1);  % Array to store distances

    % Calculate the Euclidean distance between each particle's objective values and P
    for i = 1:N
        dists(i) = pdist([Objs(i,:); P], 'euclidean');
    end

    % Sort the distances in ascending order
    sortedDists = sort(dists);

    % Randomly select a particle from the closest `number` particles
    randp = randi([2, number+1], 1, 1);  % Random index within the closest particles
    randpPos = find(dists == sortedDists(randp));  % Find the position of the selected particle

    % Return the decision variables of the selected random neighbor
    randNeighbors = Decs(randpPos(1), :);
end