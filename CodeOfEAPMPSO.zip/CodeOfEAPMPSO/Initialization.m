function Population = Initialization(Problem)
    PopDec = unifrnd(repmat(Problem.lower,Problem.N,1),repmat(Problem.upper,Problem.N,1));
    Population = Evaluation(PopDec,Problem);
end

