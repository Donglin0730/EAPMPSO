function [Pareto_front] = EAPMPSO(Problem)

% Innovation Summary:
% 1. **ESE-SNR Framework**: 
%    Three different learning strategies are integrated to handle different evolutionary states: 
%    exploration, exploitation, and balance. During exploration, random elites and mean-dimensional learning exemplars
%    are used to drive "self-cognition" and "social learning," respectively, to accelerate convergence. In the balance phase,
%    a combination of particle learning and mean-dimensional paradigms is employed to achieve a better balance between convergence
%    and diversity.

% 2. **Dynamic Oscillating Inertia Weight**:
%    Introduces dynamic oscillation in the inertia weight to enhance the algorithm's ability to fit to the optimization landscape.
%    This approach helps particles avoid premature convergence and increases the search space exploration, improving the algorithm's robustness.

% 3. **Pareto-based Bi-Indicator Infill Sampling Criterion (PBISC)**:
%    PBISC quantifies the convergence and diversity of particles using specific indicators. This criterion is employed for Pareto ranking,
%    enabling more effective particle selection during the optimization process. This enhances both the convergence and the diversity of the solutions.

    % Parameter settings
    div = 10; % Number of divisions for the grid
    wmax = 8; % Maximum number of iterations for the inner loop
    
    % Initialize the population
    Population = Initialization(Problem); % Initialize the population of particles
    Archive = UpdateArchive(Population, Problem.N); % Initialize the archive with the initial population
    foreNumOfGbest = length(Archive); % Record the number of particles in the archive
    Pbest = Population; % Initialize the personal best positions of the particles
    newObj = 0; % Initialize the new objective value
    
    % Calculate the number of iterations based on the maximum number of function evaluations
    iteration = Problem.maxFE / N; % Total number of iterations
    
    % Main optimization loop
    for i = 1:iteration
        Parents = Archive; % Set the current archive as the parent population
        w = 1; % Initialize the inner loop counter
    
        % Select the global best (gbest) individual using roulette wheel selection
        while w < wmax
            if w == 1
                REP = SelectGbest(newObj, Archive.objs, Problem, div); % Select gbest in the first iteration
            else
                REP = REPSelection(Archive.objs, Problem.N, div); % Select gbest using REP selection in subsequent iterations
            end
            w = w + 1; % Increment the inner loop counter
    
            % Check if the archive size has increased
            flag = length(Archive) >= foreNumOfGbest;
    
            % Update the population using the MYMOPSO operator
            Population = OperatorMYMOPSO(Problem, Population, Pbest, Archive(REP), flag);
    
            % Update the number of particles in the archive
            foreNumOfGbest = length(Archive);
    
            % Update the archive with the new population
            Archive = UpdateArchive([Archive, Population], Problem.N);
    
            % Update the personal best positions
            Pbest = UpdatePbest(Pbest, Population);
        end
    
        % Generate new objective values for the archive
        newObj = GenNewObj(Archive.objs, Parents);
    end
    
    % Extract the Pareto front from the final population
    Pareto_front = Population.objs;
end
