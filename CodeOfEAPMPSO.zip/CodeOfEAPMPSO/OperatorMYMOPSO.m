function Offspring = OperatorMYMOPSO(Problem,Particle,Pbest,Gbest,flag)
%OperatorMYMOPSO - The operator for particle swarm optimization.

    [proM,disM] = deal(1,20);  % Mutation probability and distribution index

    ParticleDec = Particle.decs;  % Particle decision variables
    PbestDec    = Pbest.decs;    % Personal best decision variables
    GbestDec    = Gbest.decs;    % Global best decision variables
    [N,D]       = size(ParticleDec);  % Number of particles and decision variables
    ParticleVel = Particle.adds(zeros(N,D));  % Particle velocities
    M           = Problem.M;  % Number of objectives
    CS          = zeros(N,1);  % Cosine similarity values

    numberOfNeigh = 90;  % Size of neighborhood for gbest/pbest

    threshold = 0.3 * N;  % Threshold for particle number difference

    estate = 0;  % Population state flag
    count1 = 0;
    count2 = 0;
    count3 = 0;

    % Record normalized particle objective values
    normalFitness = zeros(N,M);
    pbestObj = Pbest.objs;  % Personal best objective values
    gbestObj = Gbest.objs;  % Global best objective values

    % p1 for individual cognition, p2 for social cognition
    p1 = PbestDec;
    p2 = GbestDec;

    % Initialize particle velocity matrix
    if flag == 0
        n_utopia = 0;   % Number of particles closer to the ideal point
        n_nadir = 0;    % Number of particles closer to the nadir point
        worstObj = max(Pbest.objs);  % Worst objective value
        bestObj = min(Pbest.objs);   % Best objective value
        nadir = ones(1,M);  % Nadir point
        utopia = zeros(1,M);  % Utopia point
    
        % Normalize objective values and compute distance to ideal and nadir points
        for i = 1 : N
            normalFitness(i,:) = (pbestObj(i,:) - bestObj) / (worstObj - bestObj);
            distOfUtopia = pdist([utopia; normalFitness(i,:)], 'euclidean');
            distOfNadir = pdist([nadir; normalFitness(i,:)], 'euclidean');
            if distOfNadir > distOfUtopia
                n_utopia = n_utopia + 1;
            else
                n_nadir = n_nadir + 1;
            end
        end
    
        dif = n_nadir - n_utopia;
        if dif > threshold
            estate = 1;  % Exploration state
        elseif dif < -threshold
            estate = 3;  % Exploitation state
        elseif dif >= -threshold && dif <= threshold
            estate = 2;  % Balanced state
        end
    
        % Update velocity strategy based on the population state
        if estate == 1
            % Calculate cosine similarity between Pbest and Gbest, decide whether to update
            for i = 1 : N
                CS(i) = CosineSimilarity(gbestObj(i,:), pbestObj(i,:));
                if CS(i) < 0
                    p2(i,:) = RandNeighOfESE_SNR(Pbest, gbestObj(i,:), numberOfNeigh);
                else
                    p1(i,:) = RandNeighOfESE_SNR(Pbest, pbestObj(i,:), numberOfNeigh);
                    p2(i,:) = zeros(1, D);
                end
            end
            
        elseif estate == 3
            % Exploitation state
            p1 = ParticleDec;
    
            for i = 1 : N
                CS(i) = CosineSimilarity(gbestObj(i,:), pbestObj(i,:));
                if CS(i) < 0
                    p1(i,:) = RandNeighOfESE_SNR(Pbest, pbestObj(i,:), numberOfNeigh);
                else
                    p2(i,:) = RandNeighOfESE_SNR(Pbest, gbestObj(i,:), numberOfNeigh);
                    p1(i,:) = zeros(1, D);
                end
            end
        else 
            % Balanced state strategy
            for i = 1 : N
                p1(i,:) = RandNeighOfESE_SNR(Pbest, pbestObj(i,:), numberOfNeigh);
                p2(i,:) = RandNeighOfESE_SNR(Pbest, gbestObj(i,:), numberOfNeigh);
            end
        end
    end

    % Dynamic inertia weight
    W = DynamicInertiaWeight(Problem.FE / Problem.N, Problem.maxFE / Problem.N, Problem.N);

    % Particle swarm optimization
    r1 = repmat(rand(N,1), 1, D);  % Random value for individual cognition
    r2 = repmat(rand(N,1), 1, D);  % Random value for social cognition
    C1 = repmat(unifrnd(1.5, 2.5, N, 1), 1, D);  % Cognitive coefficient
    C2 = repmat(unifrnd(1.5, 2.5, N, 1), 1, D);  % Social coefficient

    % Update velocity and position
    OffVel = W .* ParticleVel + C1 .* r1 .* (p1 - ParticleDec) + C2 .* r2 .* (p2 - ParticleDec);
    OffDec = ParticleDec + OffVel;

    % Polynomial mutation
    Lower = repmat(Problem.lower, N, 1);  % Lower bound for decision variables
    Upper = repmat(Problem.upper, N, 1);  % Upper bound for decision variables
    Site = rand(N, D) < proM / D;  % Mutation site selection
    mu = rand(N, D);  % Random mutation factor
    temp = Site & mu <= 0.5;
    OffDec = min(max(OffDec, Lower), Upper);  % Bound the decision variables within limits
    OffDec(temp) = OffDec(temp) + (Upper(temp) - Lower(temp)) .* ((2 .* mu(temp) + (1 - 2 .* mu(temp)) .* ...
                  (1 - (OffDec(temp) - Lower(temp)) ./ (Upper(temp) - Lower(temp))) .^ (disM + 1)) .^ (1 / (disM + 1)) - 1);
    temp = Site & mu > 0.5;
    OffDec(temp) = OffDec(temp) + (Upper(temp) - Lower(temp)) .* (1 - (2 .* (1 - mu(temp)) + 2 .* (mu(temp) - 0.5) .* ...
                  (1 - (Upper(temp) - OffDec(temp)) ./ (Upper(temp) - Lower(temp))) .^ (disM + 1)) .^ (1 / (disM + 1)));

    % Evaluate the offspring solutions
    Offspring = Problem.Evaluation(OffDec, OffVel);
end