function W = DynamicInertiaWeight(FE,maxFE,N)
    y1 = 0.6-(0.2/maxFE)*FE;
    y2 = 1 - (0.6/maxFE)*FE;
    W  = zeros(N,1);
    for i = 1 : N
        if FE<=maxFE
            W(i) = y1 + rand*(y2-y1);
        else
            W(i) = 0.4;
        end
    end
end