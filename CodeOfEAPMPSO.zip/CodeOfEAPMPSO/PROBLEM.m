classdef PROBLEM < handle
%PROBLEM - The superclass of problems.
    properties
        N          = 100;      	% Population size
        maxFE      = 5000;     % Maximum number of function evaluations
        FE         = 0;        	% Number of consumed function evaluations
    end
    properties(SetAccess = protected)
        M;                    	% Number of objectives
        D;                     	% Number of decision variables
        maxRuntime = inf;      	% maximum runtime (in second)
        encoding   = 1;        	% Encoding scheme of each decision variable (1.real 2.integer 3.label 4.binary 5.permutation)
        lower      = 0;     	% Lower bound of each decision variable
        upper      = 1;        	% Upper bound of each decision variable
        optimum;              	% Optimal values of the problem
        PF;                   	% Image of Pareto front
        parameter  = {};       	% Other parameters of the problem
    end
    methods(Access = protected)
        function obj = PROBLEM(varargin)
        %PROBLEM - The constructor of PROBLEM.
            isStr = find(cellfun(@ischar,varargin(1:end-1))&~cellfun(@isempty,varargin(2:end)));
            for i = isStr(ismember(varargin(isStr),{'N','M','D','maxFE','maxRuntime','parameter'}))
                obj.(varargin{i}) = varargin{i+1};
            end
            obj.Setting();
            obj.optimum  = obj.GetOptimum(10000);
            obj.PF       = obj.GetPF();
        end
    end
    methods
        function Setting(obj)
        %Setting - Default settings of the problem.
        end
        function Population = Initialization(obj,N)
        %Initialization - Generate multiple initial solutions.
            if nargin < 2
            	N = obj.N;
            end
            PopDec = zeros(N,obj.D);
            Type   = arrayfun(@(i)find(obj.encoding==i),1:5,'UniformOutput',false);
            if ~isempty(Type{1})        % Real variables
                PopDec(:,Type{1}) = unifrnd(repmat(obj.lower(Type{1}),N,1),repmat(obj.upper(Type{1}),N,1));
            end
            if ~isempty(Type{2})        % Integer variables
                PopDec(:,Type{2}) = round(unifrnd(repmat(obj.lower(Type{2}),N,1),repmat(obj.upper(Type{2}),N,1)));
            end
            if ~isempty(Type{3})        % Label variables
                PopDec(:,Type{3}) = round(unifrnd(repmat(obj.lower(Type{3}),N,1),repmat(obj.upper(Type{3}),N,1)));
            end
            if ~isempty(Type{4})        % Binary variables
                PopDec(:,Type{4}) = logical(randi([0,1],N,length(Type{4})));
            end
            if ~isempty(Type{5})        % Permutation variables
                [~,PopDec(:,Type{5})] = sort(rand(N,length(Type{5})),2);
            end
            Population = obj.Evaluation(PopDec);
        end
        function Population = Evaluation(obj,varargin)
        %Evaluation - Evaluate multiple solutions.
            PopDec     = obj.CalDec(varargin{1});
            PopObj     = obj.CalObj(PopDec);
            PopCon     = obj.CalCon(PopDec);
            Population = SOLUTION(PopDec,PopObj,PopCon,varargin{2:end});
            obj.FE     = obj.FE + length(Population);
        end
        function PopDec = CalDec(obj,PopDec)
        %CalDec - Repair multiple invalid solutions.
            Type  = arrayfun(@(i)find(obj.encoding==i),1:5,'UniformOutput',false);
            index = [Type{1:3}];
            if ~isempty(index)
                PopDec(:,index) = max(min(PopDec(:,index),repmat(obj.upper(index),size(PopDec,1),1)),repmat(obj.lower(index),size(PopDec,1),1));
            end
            index = [Type{2:5}];
            if ~isempty(index)
                PopDec(:,index) = round(PopDec(:,index));
            end
        end
        function PopObj = CalObj(obj,PopDec)
        %CalObj - Calculate the objective values of multiple solutions.
            PopObj = zeros(size(PopDec,1),1);
        end
        function PopCon = CalCon(obj,PopDec)
        %CalCon - Calculate the constraint violations of multiple solutions.
            PopCon = zeros(size(PopDec,1),1);
        end
    end
end