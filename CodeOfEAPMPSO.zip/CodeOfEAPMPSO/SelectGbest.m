function REP = SelectGbest(newObj, PopObj, Problem, div)
    % Select the global best individual based on the objective values and population

    % If the function evaluations are equal to 100, use REP selection
    if Problem.FE == 100
        REP = REPSelection(PopObj, Problem.N, div);
    else
        % Perform non-dominated sorting on the new objective values
        [FrontNo, MaxFNo] = NDSort(newObj, inf);  % FrontNo stores the rank of each particle, MaxFNo is the maximum front number
        num_elements = MaxFNo;  % Total number of fronts
        FrontSatic = cell(MaxFNo, length(newObj));  % Cell array to store the index of particles in each front
        FrontCount = hist(FrontNo, 1:MaxFNo);  % Count of particles in each front

        % Organize the particles in each front
        for i = 1 : MaxFNo
            len = length(find(FrontNo == i));  % Length of the i-th front
            FrontSatic(i, 1:len) = num2cell(find(FrontNo == i));  % Store the indices of particles in the i-th front
        end

        % Assign probabilities to each front
        probabilities = linspace(1, 0, MaxFNo);  % Linearly decreasing probability from 1 to 0
        probabilities = probabilities / sum(probabilities);  % Normalize the probabilities

        % If probabilities contain NaN, set them to 1
        if isnan(probabilities)
            probabilities = 1;
        end

        % Randomly select particles based on the calculated probabilities
        selected_indices = randsample(1:num_elements, Problem.N, true, probabilities);

        % Select the global best particles based on the selected indices
        for i = 1:Problem.N
            REP(i) = cell2mat(FrontSatic(selected_indices(i), randi([1, FrontCount(selected_indices(i))])));
        end
    end
end