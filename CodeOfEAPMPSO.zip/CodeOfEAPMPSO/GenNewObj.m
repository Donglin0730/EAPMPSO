function newObj = GenNewObj(Objs,Parents)
    %% Pareto-based bi-indicator infill sampling criterion
    DAobj = Objs; % Objective values of candidate solutions
    DA = Parents; % Parent population
    
    %% Normalization
    % Normalize the objective values of the parent population
    DA_Nor = (DA.objs - repmat(min([DAobj; DA.objs], [], 1), length(DA), 1)) ...
        ./ repmat(max([DAobj; DA.objs], [], 1) - min([DAobj; DA.objs], [], 1), length(DA), 1);
    
    % Normalize the objective values of the candidate solutions
    DA_Nor_pre = (DAobj - repmat(min([DAobj; DA.objs], [], 1), size(DAobj, 1), 1)) ...
        ./ repmat(max([DAobj; DA.objs], [], 1) - min([DAobj; DA.objs], [], 1), size(DAobj, 1), 1);
    
    % Find the minimum values of the normalized objectives
    Zmin = min([DA_Nor; DA_Nor_pre], [], 1);
    
    % Initialize a matrix to store distances between candidate solutions and parents
    dist_D = zeros(size(DA_Nor_pre, 1), size(DA_Nor, 1));
    
    %% Calculate the distance between candidate solutions and parents
    for i = 1:size(DA_Nor_pre, 1)
        for j = 1:size(DA_Nor, 1)
            % Compute the Euclidean distance between candidate i and parent j
            dist_D(i, j) = norm(DA_Nor_pre(i, :) - DA_Nor(j, :), 2);
        end
    end
    
    %% Diversity Indicator
    % Compute the diversity indicator as the negative minimum distance to the parents
    DI = -min(dist_D, [], 2);
    
    %% Calculate the distance between candidate solutions and the ideal point
    % Compute the Euclidean distance between each candidate and the ideal point (Zmin)
    dist_C = pdist2(DA_Nor_pre, repmat(Zmin, size(DA_Nor_pre, 1), 1));
    
    %% Convergence Indicator
    % Use the distance to the ideal point as the convergence indicator
    CI = dist_C(:, 1);
    
    % Combine diversity and convergence indicators into a new objective matrix
    newObj = [DI, CI];
end

